<?php
require '../database/koneksi.php';

$_SESSION['page'] = "warna";
require 'header/header.php';
require 'navbar/navbar_menu.php';

if (isset($_SESSION['log'])) {
} else {
    header('location:index.php');
};
?>

                        <li class="breadcrumb-item active">Data user</li>
                    </ol>
                    <div class="card mb-4">
                        <div class="card-header">
                            <!-- Button to Open the Modal -->
                            <?php 
                            if ($_SESSION['admin'] == True) {
                                echo '<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal">
                                Tambah warna</button>';
                            }
                            else{
                                
                            }
                            ?>
                            
                        </div>

                        <!-- TABEL GURU -->
                        <div class="card-body">
                            <?php 
                            if ($_SESSION['admin'] == True) {
                                ?>
                                <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Warna</th>
                                        <th>Bidang Perusahaan</th>
                                        <th>Kesan Emosional</th>
                                        <th>Target market</th>
                                        <th>Warna 1</th>
                                        <th>Warna 2</th>
                                        <th>Warna 3</th>
                                        <th>Warna 4</th>
                                        <th>Warna 5</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $datawarna = mysqli_query($koneksi, "SELECT * FROM warna");
                                    $i = 1;
                                    while ($data = mysqli_fetch_array($datawarna)) {
                                        $idw = $data['id_warna'];
                                        $nama_warna = $data['nama_warna'];
                                        $kategori_1 = $data['kategori_1'];
                                        $kategori_2 = $data['kategori_2'];
                                        $kategori_3 = $data['kategori_3'];
                                        $warna_1    = $data['warna_1'];
                                        $warna_2    = $data['warna_2'];
                                        $warna_3    = $data['warna_3'];
                                        $warna_4    = $data['warna_4'];
                                        $warna_5    = $data['warna_5'];
                                    ?>
                                        <tr>
                                            <td><?= $i++; ?></td>
                                            <td><?= $nama_warna; ?></td>
                                            <td><?= $kategori_1; ?></td>
                                            <td><?= $kategori_2; ?></td>
                                            <td><?= $kategori_3; ?></td>
                                            <td><?= $warna_1; ?></td>                                            
                                            <td><?= $warna_2; ?></td>
                                            <td><?= $warna_3; ?></td>
                                            <td><?= $warna_4; ?></td>
                                            <td><?= $warna_5; ?></td>
                                            <td>
                                                <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#edit<?= $idw; ?>">Edit</button>
                                                <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#delete<?= $idw; ?>">Delete</button>
                                            </td>
                                        </tr>
                                        <!-- Edit Modal -->
                                        <div class="modal" id="edit<?= $idw; ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content">

                                                    <!-- Modal Header -->
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Edit Warna</h4>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>

                                                    <!-- Modal body -->
                                                    <form method="post">
                                                        <div class="modal-body">
                                                            <input type="text" name="nama_warna" value="<?= $nama_warna ?>" class="form-control" >
                                                            <br>
                                                            <label>Bidang Perusahaan</label>
                                                            <select name="kategori_1" class="form-control" style="color: black; border-radius: 5px;" required>
                                                                <option value=""></option>
                                                                <option value="F&B">F&B</option>
                                                                <option value="Finance">Finance</option>
                                                                <option value="Agrarin">Agrarin</option>
                                                                <option value="Service">Service</option>
                                                            </select>
                                                            <br>
                                                            <label>Kesan Emosional</label>
                                                            <select name="kategori_2" class="form-control" style="color: black; border-radius: 5px;" >
                                                                <option value=""></option>
                                                                <option value="Menenangkan">Menenangkan</option>
                                                                <option value="Playfulness">Playfulness</option>
                                                                <option value="Tenderness and Love">Tenderness and Love</option>
                                                                <option value="Keceriaan dan Senang">Keceriaan dan Senang</option>
                                                            </select>
                                                            <br>
                                                            <label>Taget Market</label>
                                                            <select name="kategori_3" class="form-control" style="color: black; border-radius: 5px;" >
                                                                <option value=""></option>
                                                                <option value="Age 8-10">Age 8-10</option>
                                                                <option value="Age 15-20">Age 15-20</option>
                                                                <option value="Age 20-30">Age 20-30</option>
                                                                <option value="Age 30 and over">Age 30 and over</option>
                                                            </select>
                                                            <br>
                                                            <input type="text" name="warna_1" value="<?= $warna_1 ?>" class="form-control" required>
                                                            <br>
                                                            <input type="text" name="warna_2" value="<?= $warna_1 ?>" class="form-control" required>
                                                            <br>
                                                            <input type="text" name="warna_3" value="<?= $warna_3 ?>" class="form-control" required>
                                                            <br>
                                                            <input type="text" name="warna_4" value="<?= $warna_4 ?>" class="form-control" required>
                                                            <br>
                                                            <input type="text" name="warna_5" value="<?= $warna_5 ?>" class="form-control" required>
                                                            <br>
                                                            <input type="hidden" name="idw" value="<?= $idw; ?>">
                                                            <button type="submit" class="btn btn-primary" name="update_warna">Simpan</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Hapus Modal -->
                                        <div class="modal" id="delete<?= $idw; ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content">

                                                    <!-- Modal Header -->
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Hapus Data Warna</h4>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>

                                                    <!-- Modal body -->
                                                    <form method="post">
                                                        <div class="modal-body">
                                                            Apakah Yakin Hapus Warna <?= $nama_warna; ?> ?
                                                            <br>
                                                            <input type="hidden" name="idw" value="<?= $idw; ?>">
                                                            <br>
                                                            <button type="submit" class="btn btn-danger" name="Hapus_warna">Ya, Hapus</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php
                                    }}
                                    ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </main>
<?php 
require 'footer/footer.php';
?>


<!-- The Modal -->
<div class="modal" id="myModal">
    <div class="modal-dialog">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">Tambah Warna Baru</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <!-- Modal body -->
            <form method="post">
                <div class="modal-body">
                    <input type="text" name="nama_warna" placeholder="Nama Warna" class="form-control" required>
                    <br>
                    <label>Bidang Perusahaan</label>
                    <select name="kategori_1" class="form-control" style="color: black; border-radius: 5px;" required>
                        <option value=""></option>
                        <option value="F&B">F&B</option>
                        <option value="Finance">Finance</option>
                        <option value="Agrarin">Agrarin</option>
                        <option value="Service">Service</option>
                    </select>
                    <br>
                    <label>Kesan Emosional</label>
                    <select name="kategori_2" class="form-control" style="color: black; border-radius: 5px;" required>
                        <option value=""></option>
                        <option value="Menenangkan">Menenangkan</option>
                        <option value="Playfulness">Playfulness</option>
                        <option value="Tenderness and Love">Tenderness and Love</option>
                        <option value="Keceriaan dan Senang">Keceriaan dan Senang</option>
                    </select>
                    <br>
                    <label>Taget Market</label>
                    <select name="kategori_3" class="form-control" style="color: black; border-radius: 5px;" required>
                        <option value=""></option>
                        <option value="Age 8-10">Age 8-10</option>
                        <option value="Age 15-20">Age 15-20</option>
                        <option value="Age 20-30">Age 20-30</option>
                        <option value="Age 30 and over">Age 30 and over</option>
                    </select>
                    <br>
                    <input type="text" name="warna_1" placeholder="Warna 1" class="form-control" required>
                    <br>
                    <input type="text" name="warna_2" placeholder="Warna 2" class="form-control" required>
                    <br>
                    <input type="text" name="warna_3" placeholder="Warna 3" class="form-control" required>
                    <br>
                    <input type="text" name="warna_4" placeholder="Warna 4" class="form-control" required>
                    <br>
                    <input type="text" name="warna_5" placeholder="Warna 5" class="form-control" required>
                    <br>
                    <button type="submit" class="btn btn-primary" name="tambah_warna">Tambah</button>
                </div>
            </form>

            <!-- Modal footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
</html>