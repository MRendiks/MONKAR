<?php
session_start();

//Membuat Koneksi ke Database
$koneksi = mysqli_connect("localhost", "root", "", "colorku");

//Cek Koneksi Database
if (mysqli_connect_error()) {
	echo "koneksi database gagal :" . mysqli_connect_error();
}


//INSERT
if (isset($_POST['tambah_user'])) {
	$nama_user = $_POST['nama_user'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$status = $_POST['status'];
	
	$adduser = mysqli_query($koneksi, "INSERT INTO users VALUES('', '$nama_user', '$username', '$status', '$password')") or die("Erro in query $adduser.".mysqli_error($koneksi));
	if ($adduser) {
		header("location:data_costumer.php");
	}else{
		header('location:data_costumer.php');
	}
}

if (isset($_POST['tambah_warna'])) {
	$nama_warna = $_POST['nama_warna'];
	$kategori_1 = $_POST['kategori_1'];
	$kategori_2 = $_POST['kategori_2'];
	$kategori_3 = $_POST['kategori_3'];
	$warna_1	= $_POST['warna_1'];
	$warna_2	= $_POST['warna_2'];
	$warna_3	= $_POST['warna_3'];
	$warna_4	= $_POST['warna_4'];
	$warna_5	= $_POST['warna_5'];
	
	$addwarna = mysqli_query($koneksi, "INSERT INTO warna VALUES('', '$nama_warna', '$kategori_1', '$kategori_2', '$kategori_3', '$warna_1', '$warna_2', '$warna_3', '$warna_4', '$warna_5')") or die("Erro in query $addwarna.".mysqli_error($koneksi));
	if ($addwarna) {
		header("location:data_warna.php");
	}else{
		header('location:data_warna.php');
	}
}



#UPDATE

if(isset($_POST['update_user'])) {
	$ids = $_POST['ids'];
	$nama_user = $_POST['nama_user'];
	$username = $_POST['username'];
	$status = $_POST['status'];
	$password = $_POST['password'];

	$update = mysqli_query($koneksi, "UPDATE users SET nama='$nama_user', username='$username', password='$password', status='$status' WHERE id_user='$ids'") or die("Erro in query $update.".mysqli_error($koneksi));

	if ($update) {
		header("location:data_costumer.php");
	}else{
		header("location:data_costumer.php");
	}
}


if (isset($_POST['updatepassword'])) {
	$id_user = $_POST['id_user'];
	$password = $_POST['password'];

	$update = mysqli_query($koneksi, "UPDATE users SET password='$password' WHERE id_user='$id_admin'");
	if ($update) {
		header("location:ganti_password.php");
	}else{
		header("location:ganti_password.php");
	}
}

if (isset($_POST['update_warna'])) {
	$idw 		= $_POST['idw'];
	$nama_warna = $_POST['nama_warna'];
	$kategori_1 = $_POST['kategori_1'];
	$kategori_2 = $_POST['kategori_2'];
	$kategori_3 = $_POST['kategori_3'];
	$warna_1	= $_POST['warna_1'];
	$warna_2	= $_POST['warna_2'];
	$warna_3	= $_POST['warna_3'];
	$warna_4	= $_POST['warna_4'];
	$warna_5	= $_POST['warna_5'];

	$update = mysqli_query($koneksi, "UPDATE warna SET nama_warna='$nama_warna', kategori_1='$kategori_1', kategori_2='$kategori_2', kategori_3='$kategori_3', warna_1='$warna_1', warna_2='$warna_2', warna_3='$warna_3', warna_4='$warna_4', warna_5='$warna_5' WHERE id_warna='$idw'");
	if ($update) {
		header("location:data_warna.php");
	}else{
		header("location:data_warna.php");
	}
	
}


// HAPUS DATA




if (isset($_POST['hapus_user'])) {
	$ids = $_POST['ids'];

	$hapus = mysqli_query($koneksi, "DELETE FROM users where id_user='$ids'");

	if ($hapus) {
		header("location:data_costumer.php");
	} else {
		header("location:data_costumer.php");
	}
}

if (isset($_POST['hapus_warna'])) {
	$idw = $_POST['idw'];

	$hapus = mysqli_query($koneksi, "DELETE FROM warna where id_warna='$idw'") or die("Erro in query $hapus.".mysqli_error($koneksi));
	if ($hapus) {
		header("location:data_warna.php");
	} else {
		header("location:data_warna.php");
	}
}


?>