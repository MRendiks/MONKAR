<?php 
require 'connect_db.php';

$kategori_1   = $_POST['kategori_1'];
$kategori_2   = $_POST['kategori_2'];
$kategori_3   = $_POST['kategori_3'];

$query      = "SELECT * FROM warna WHERE kategori_1='$kategori_1' AND kategori_2='$kategori_2' AND kategori_3='$kategori_3'";
$odj_query  = mysqli_query($koneksi, $query);
$data       = mysqli_fetch_array($odj_query);


if ($data) {
    echo json_encode(
        array(
            'response' => true,
            "nama_warna" => $data["nama_warna"],
            "warna_1" => $data["warna_1"],
            "warna_2" => $data["warna_2"],
            "warna_3" => $data["warna_3"],
            "warna_4" => $data["warna_4"],
            "warna_5" => $data["warna_5"]
        )
    );
}else {
    echo json_encode(
        array(
            'response' => false,
            'payload' => null
        )
    );
}

header('Content-Type: application/json');



?>